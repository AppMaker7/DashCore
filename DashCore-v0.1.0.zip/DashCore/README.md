# DashCore

A free, mobile-friendly Geometry Dash practice companion prototype.

## What works in v0.1
- Responsive dark-purple / cyan dashboard.
- Local Noclip preference toggle.
- Local target-speed preference (0.5×–2.0×).
- Local profile persistence using browser storage.
- PWA manifest and service worker for installability.

## Important limitation
The Noclip and Speed controls in this version are **preferences only**. This PWA does not inject code, patch, inspect, or control the official Geometry Dash app. Android isolates apps from one another. Actual in-game modifications require a separately authorized and compatible integration method.

## Run locally
Serve this folder from a local static web server, or deploy it to GitHub Pages. PWA installation requires HTTPS (GitHub Pages provides HTTPS).

## Deploy with GitHub Pages
1. Upload the contents of this folder to the repository root.
2. In GitHub, open **Settings → Pages**.
3. Choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
4. Open the published HTTPS site in Chrome on Android and use **Install app** or **Add to Home screen**.

DashCore is an independent fan-made companion and is not affiliated with RobTop Games.
